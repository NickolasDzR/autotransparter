module.exports = {
    presets: [
        require("@babel/preset-env")
    ],
    "ignore": [
        "**/index.js"
    ]
};